#!/usr/bin/ruby -w

def func_c
  i = 0
  while i < 20000
    i = i + 1
  end
end

def func_b
  i = 0
  while i < 40000
    i = i + 1
  end
end

def func_a
  i = 0
  while i < 60000
    i = i + 1
  end
end

while true
  func_a
  func_b
  func_c
  sleep 1
end
