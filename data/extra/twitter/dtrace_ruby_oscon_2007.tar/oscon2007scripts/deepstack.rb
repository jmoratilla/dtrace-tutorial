#!/usr/bin/ruby -w

def parserfunc1(str, depth)
  depth += 1
  if depth < 50
    parserfunc2(str, depth)
  else
    @string = (str.string rescue str)
    str.bogus(depth)
  end
  rescue NoMethodError => detail
     msg = detail
end

def parserfunc2(str, depth)
  depth += 1
  if depth < 50
    parserfunc1(str, depth)
  else
    @string = (str.string rescue str)
    str.bogus(depth)
  end
  rescue NoMethodError => detail
     msg = detail
end

str = String.new("a string")

while true
  depth = 0

  begin
    parserfunc1(str, depth)
  end
end
