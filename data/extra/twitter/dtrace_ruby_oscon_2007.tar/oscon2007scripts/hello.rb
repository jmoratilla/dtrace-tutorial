#!/usr/bin/ruby -w

def hello
  print "Hello DTrace!\n"
end

hello
